﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace crud_sql
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            GetEmpList();
        }

        SqlConnection con = new SqlConnection("Data Source=GUNJAN\\SPARAT;Initial Catalog=TestSP_DB;User ID=sa;Password=Sql12@");



            private void Form1_Load(object sender, EventArgs e)
            {
               GetEmpList();
            }

            private void button6_Click(object sender, EventArgs e)
            {

               int empid = int.Parse(textBox5.Text);
               string empname = textBox6.Text, city = comboBox2.Text, contact = textBox8.Text,sex ="";
               double age = double.Parse(textBox7.Text);
                DateTime joindate = DateTime.Parse(dateTimePicker2.Text);
                if(radioButton3.Checked==true) { sex = "male"; } else { sex = "female"; }


              SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "InsertEmp_SP";
                cmd.Parameters.AddWithValue("@EmpID", textBox5.Text);
                cmd.Parameters.AddWithValue("@EmpNmae", textBox6.Text);
                cmd.Parameters.AddWithValue("@City", comboBox2.Text);
                cmd.Parameters.AddWithValue("@Age", textBox7.Text);
                if (radioButton3.Checked == true) { cmd.Parameters.AddWithValue("@Sex", radioButton3.Text); }

               else if(radioButton4.Checked == false){cmd.Parameters.AddWithValue("@Sex", radioButton4.Text); }




                cmd.Parameters.AddWithValue("@JoiningDate", dateTimePicker2.Text);
               cmd.Parameters.AddWithValue("@Contact", textBox8.Text);
                con.Open();
               cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Successfully Inserted");
                GetEmpList();

            }



            void GetEmpList()
            {
               SqlCommand c = new SqlCommand("exec ListEmp_SP ", con);
                SqlDataAdapter sd = new SqlDataAdapter(c);
              DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridView2.DataSource = dt;
            }

                private void button7_Click(object sender, EventArgs e)
                {
                    // update

                    int empid = int.Parse(textBox5.Text);
                    string empname = textBox6.Text, city = comboBox2.Text, contact = textBox8.Text, sex = "";
                    double age = double.Parse(textBox7.Text);
                    DateTime joindate = DateTime.Parse(dateTimePicker2.Text);
                    if (radioButton3.Checked == true) { sex = "male"; } else { sex = "female"; }


                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "UpdateEmp_SP";
                    cmd.Parameters.AddWithValue("@EmpID", textBox5.Text);
                    cmd.Parameters.AddWithValue("@EmpNmae", textBox6.Text);
                    cmd.Parameters.AddWithValue("@City", comboBox2.Text);
                    cmd.Parameters.AddWithValue("@Age", textBox7.Text);



                    if (radioButton3.Checked == true) { cmd.Parameters.AddWithValue("@Sex", radioButton3.Text); }

                    else if (radioButton4.Checked == false) { cmd.Parameters.AddWithValue("@Sex", radioButton4.Text); }


                    cmd.Parameters.AddWithValue("@JoiningDate", dateTimePicker2.Text);
                    cmd.Parameters.AddWithValue("@Contact", textBox8.Text);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    MessageBox.Show("Successfully updated");
                    GetEmpList();

                }

                private void button8_Click_1(object sender, EventArgs e)
                {
                    //delete

                    int empid = int.Parse(textBox5.Text);


                    // SqlCommand c = new SqlCommand("exec DeleteEmp_SP '" + empid + "'", con);


                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "DeleteEmp_SP";
                    cmd.Parameters.AddWithValue("@EmpID", textBox5.Text);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();





                    MessageBox.Show("Successfully Deleted");
                    GetEmpList();


                }

                private void button9_Click_1(object sender, EventArgs e)
                {
                    //load specfic employee

                    int empid = int.Parse(textBox5.Text);


                    // SqlCommand c = new SqlCommand("exec DeleteEmp_SP '" + empid + "'", con);

                     SqlCommand c = new SqlCommand("exec  LoadEmp_SP", con);
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "LoadEmp_SP";
                    cmd.Parameters.AddWithValue("@EmpID", textBox5.Text);
                    con.Open();
                    SqlDataAdapter sd = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    sd.Fill(dt);
                    dataGridView2.DataSource = dt;

                    con.Close();


                }

                private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
                {

                }

                private void pictureBox1_Click(object sender, EventArgs e)
            {

            }

                private void label4_Click(object sender, EventArgs e)
                {
                    
            {

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button51_Click(object sender, EventArgs e)
        {

        //    string gender;
        //    if (radioButton1.Checked == true)
        //        gender = "male";
        //    else
        //        gender = "female";

        //    this.insertEmp_SPTableAdapter.Fill(dataSet1.InsertEmp_SP, Convert.ToInt32(textBox1.Text), textBox2.Text, comboBox1.Text, Convert.ToDouble
        //        (textBox3.Text), gender, Convert.ToDateTime(dateTimePicker1), textBox4.Text);
        }

        private void button61_Click(object sender, EventArgs e)
        {
            //string gender;
            //if (radioButton3.Checked == true)
            //    gender = "male";
            //else
            //    gender = "female";

            //this.insertEmp_SPTableAdapter.Fill(dataSet1.InsertEmp_SP, Convert.ToInt32(textBox5.Text), textBox6.Text, comboBox2.Text, Convert.ToDouble
            //    (textBox7.Text), gender, Convert.ToDateTime(dateTimePicker2), textBox8.Text);
        }

        private void button11_Click(object sender, EventArgs e)
        {
        
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
            //GetEmpList();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
