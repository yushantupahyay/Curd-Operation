﻿namespace crud_sql
{


    partial class DataSet1
    {
        partial class LoadEmp_SPDataTable
        {
        }
    }
}
